obj = JSON.parse("{\"a\":2e10}")
@test obj["a"] == 2e10
